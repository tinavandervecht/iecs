# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 192.168.10.10 (MySQL 5.7.17-0ubuntu0.16.04.2)
# Database: iecs
# Generation Time: 2018-05-09 13:26:20 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table tbl_activity
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_activity`;

CREATE TABLE `tbl_activity` (
  `activity_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `company_id` smallint(6) NOT NULL,
  `activity_desc` text NOT NULL,
  `activity_date` datetime NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table tbl_admin
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_admin`;

CREATE TABLE `tbl_admin` (
  `admin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(15) NOT NULL,
  `admin_pw` varchar(255) NOT NULL DEFAULT '',
  `admin_name` varchar(30) NOT NULL,
  `admin_lastLogin` int(11) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;

INSERT INTO `tbl_admin` (`admin_id`, `admin_username`, `admin_pw`, `admin_name`, `admin_lastLogin`)
VALUES
	(1,'admin','$2y$10$JJaewemK8NUtZSUP1jRZT.lEJNQRKdtZhxif9ffnxGo2fpEq5rqw6','Admin User',1525469316);

/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tbl_company
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_company`;

CREATE TABLE `tbl_company` (
  `company_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(150) NOT NULL,
  `company_email` varchar(40) NOT NULL DEFAULT 'Your Email Here',
  `company_phone` varchar(12) NOT NULL DEFAULT '000-000-0000',
  `company_pw` varchar(255) NOT NULL DEFAULT '',
  `company_date` datetime NOT NULL,
  `company_contactName` varchar(30) NOT NULL,
  `company_lastLogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `company_status` smallint(1) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `tbl_company` WRITE;
/*!40000 ALTER TABLE `tbl_company` DISABLE KEYS */;

INSERT INTO `tbl_company` (`company_id`, `company_name`, `company_email`, `company_phone`, `company_pw`, `company_date`, `company_contactName`, `company_lastLogin`, `company_status`)
VALUES
	(1,'Test Company','testcompany@email.com','123-456-7890','$2y$10$FuSGY96ZlwWqW.ZQcOLSb.4R/esHmTajX7yotEg49kDYKamHY2QVe','2016-10-11 10:53:13','Test User Name','2018-05-04 20:06:59',1);

/*!40000 ALTER TABLE `tbl_company` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tbl_estimates
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_estimates`;

CREATE TABLE `tbl_estimates` (
  `estimate_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` smallint(5) unsigned NOT NULL,
  `estimate_name` varchar(50) NOT NULL,
  `estimate_date` datetime NOT NULL,
  `estimate_projectedDate` varchar(50) NOT NULL DEFAULT 'Not Specified',
  `estimate_address` varchar(50) NOT NULL DEFAULT 'Not Specified',
  `estimate_engineer` varchar(50) NOT NULL DEFAULT 'Not Specified',
  `estimate_status` smallint(1) NOT NULL,
  `estimate_location` varchar(50) NOT NULL,
  `estimate_expectedFlow` decimal(5,2) NOT NULL,
  `estimate_expectedVelocity` decimal(5,2) NOT NULL,
  `estimate_offset` decimal(5,2) NOT NULL,
  `estimate_bedSlope` decimal(5,2) NOT NULL,
  `estimate_sideSlope` decimal(5,2) NOT NULL,
  `estimate_friction` decimal(5,0) NOT NULL DEFAULT '30',
  `estimate_flowType` smallint(2) NOT NULL COMMENT 'needs review, option form?',
  `estimate_blockType` tinyint(1) NOT NULL,
  `estimate_blockUse` tinyint(1) NOT NULL,
  `estimate_bedWidth` decimal(5,2) NOT NULL,
  `estimate_alignment` smallint(1) NOT NULL,
  `estimate_crestRadius` decimal(5,0) NOT NULL DEFAULT '0',
  `estimate_channelLength` decimal(5,0) NOT NULL DEFAULT '0',
  `estimate_channelDepth` decimal(5,0) NOT NULL DEFAULT '0',
  `estimate_topWidth` decimal(5,0) NOT NULL DEFAULT '0',
  `estimate_outLetSource` smallint(2) NOT NULL,
  `estimate_modifiedDate` datetime NOT NULL,
  `estimate_comments` text NOT NULL,
  `estimate_sent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`estimate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table tbl_products
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_products`;

CREATE TABLE `tbl_products` (
  `products_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(40) NOT NULL,
  `product_number` tinyint(4) NOT NULL,
  `product_b` decimal(8,1) NOT NULL,
  `product_bT` decimal(8,1) NOT NULL,
  `product_hB` decimal(8,1) NOT NULL,
  `product_W` decimal(8,2) NOT NULL,
  `product_Ws` decimal(8,2) NOT NULL,
  PRIMARY KEY (`products_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `tbl_products` WRITE;
/*!40000 ALTER TABLE `tbl_products` DISABLE KEYS */;

INSERT INTO `tbl_products` (`products_id`, `product_name`, `product_number`, `product_b`, `product_bT`, `product_hB`, `product_W`, `product_Ws`)
VALUES
	(1,'CCG2a',25,393.7,190.5,79.8,71.22,41.50),
	(2,'CC35',35,393.7,292.1,114.3,292.70,159.90),
	(3,'CC45',45,393.7,292.1,135.7,371.80,209.60),
	(4,'CC70',70,393.7,292.1,215.9,577.50,326.70),
	(5,'CC90',90,802.6,27.6,701.0,2933.09,1735.58),
	(8,'CCG2b',25,393.7,221.0,79.8,71.22,41.50);

/*!40000 ALTER TABLE `tbl_products` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
